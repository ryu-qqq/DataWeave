from enum import Enum


class Sort(str, Enum):

    ASC = "ASC"
    DESC = "DESC"
